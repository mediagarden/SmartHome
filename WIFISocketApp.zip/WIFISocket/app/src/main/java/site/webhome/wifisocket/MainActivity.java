package site.webhome.wifisocket;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            default:
        }
        return true;
    }

    /*
    private void showRouterSettingsDialog()
    {
        LayoutInflater factory = LayoutInflater.from(MainActivity.this);//提示框
        final View view = factory.inflate(R.layout.layout_router_settings, null);//这里必须是final的
        final EditText edit = (EditText) view.findViewById(R.id.etApName_RouterSettings);//获得输入框对象

        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setView(view);
        dialog.setCancelable(true);
        dialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getApplicationContext(), "OK Click", Toast.LENGTH_LONG).show();
            }
        });
        dialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getApplicationContext(), "Cancel Click", Toast.LENGTH_LONG).show();
            }
        });
        dialog.show();
    }

    private void showSTASettingsDialog()
    {
        LayoutInflater factory = LayoutInflater.from(MainActivity.this);//提示框
        final View view = factory.inflate(R.layout.layout_sta_settings, null);//这里必须是final的
        final EditText edit = (EditText) view.findViewById(R.id.etApName_STASettings);//获得输入框对象

        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setView(view);
        dialog.setCancelable(true);
        dialog.setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getApplicationContext(), "OK Click", Toast.LENGTH_LONG).show();
            }
        });
        dialog.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getApplicationContext(), "Cancel Click", Toast.LENGTH_LONG).show();
            }
        });
        dialog.show();

    }
    */

}
